# ORSim: Open Source Distributed Agent Based Simulation Library

ORSim is born out of a development Program called OpenRoad which is a set of libraries, tools and solvers to make research on Geo-Spatial problems Accessible.

OR in ORSim can refer to the Originating Project OpenRoad. It also refers to Operations Research and the Supporting Research lab IORA.


ORSim aims to be technology and platform Neutral even though the early versions are closely tied to other Open Source tech stacks such as RabbitMQ.
