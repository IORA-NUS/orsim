

class ORSimEnv:

    messenger_settings = None


    @classmethod
    def set_backend(cls, settings):
        cls.messenger_settings = settings
